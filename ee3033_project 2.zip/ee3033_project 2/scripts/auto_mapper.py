#!/usr/bin/env python3
"""
teleop_slam.py  —  Phase 1: Keyboard Teleoperation + SLAM + Auto Map Save
=========================================================================
Run on your LAPTOP after launching mapping on the robot.
"""

import os
import sys
import select
import signal
import subprocess
import threading
import termios
import tty

import rospy
from geometry_msgs.msg import Twist

MAP_SAVE_PATH = os.path.expanduser('~/demo_map')
LINEAR_SPEED = 0.20
ANGULAR_SPEED = 0.50
PUBLISH_HZ = 10

GRN = '\033[92m'
YEL = '\033[93m'
RED = '\033[91m'
CYN = '\033[96m'
BLD = '\033[1m'
RST = '\033[0m'

BANNER = f"""
{CYN}{BLD}╔══════════════════════════════════════════════════╗
║       TELEOP SLAM CONTROLLER  —  Phase 1         ║
╠══════════════════════════════════════════════════╣
║  W / ↑      Forward          S / ↓   Backward   ║
║  A / ←      Turn Left        D / →   Turn Right ║
║  SPACE      Stop             +/-     Speed adj. ║
║  M          Save map         Q       Save & Quit║
╚══════════════════════════════════════════════════╝{RST}
"""


class TeleopSlam:
    def __init__(self):
        rospy.init_node('teleop_slam', anonymous=True)

        self.pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.linear = LINEAR_SPEED
        self.angular = ANGULAR_SPEED

        self._twist = Twist()
        self._lock = threading.Lock()
        self.running = True
        self.saved = False

        signal.signal(signal.SIGINT, self._sigint)

    def _sigint(self, *_):
        self.running = False

    @staticmethod
    def _print(colour, msg):
        print(f'\n{colour}{BLD}[SLAM]{RST}  {msg}', flush=True)

    def _status(self, label, detail=''):
        pad = ' ' * max(0, 40 - len(label) - len(detail))
        sys.stdout.write(f'\r{BLD}[{GRN}{label}{RST}{BLD}]{RST} {detail}{pad}')
        sys.stdout.flush()

    def save_map(self):
        if self.saved:
            self._print(YEL, 'Map already saved — skipping.')
            return

        self._print(CYN, f'Saving map to {MAP_SAVE_PATH}.[yaml|pgm] ...')

        self.pub.publish(Twist())
        rospy.sleep(1.0)

        try:
            save_dir = os.path.dirname(MAP_SAVE_PATH)
            if save_dir and not os.path.exists(save_dir):
                os.makedirs(save_dir)

            # Python 3.6 compatible: no capture_output, no text
            res = subprocess.run(
                ['rosrun', 'map_server', 'map_saver', '-f', MAP_SAVE_PATH],
                timeout=20,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True
            )

            if res.returncode == 0:
                yaml_file = MAP_SAVE_PATH + '.yaml'
                pgm_file = MAP_SAVE_PATH + '.pgm'

                if os.path.exists(yaml_file) and os.path.exists(pgm_file):
                    self.saved = True
                    self._print(
                        GRN,
                        f'Map saved!  →  {yaml_file}  &  {pgm_file}'
                    )
                else:
                    self._print(
                        RED,
                        'map_saver reported success, but output files were not found.'
                    )
            else:
                self._print(RED, f'map_saver error:\n{res.stderr.strip()}')

        except subprocess.TimeoutExpired:
            self._print(RED, 'map_saver timed out after 20 s.')
        except FileNotFoundError:
            self._print(RED, 'rosrun not found. Is your ROS environment sourced?')
        except Exception as e:
            self._print(RED, f'Unexpected error while saving map: {e}')

    def _key_thread(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        tty.setraw(fd)
        try:
            while self.running and not rospy.is_shutdown():
                ready, _, _ = select.select([sys.stdin], [], [], 0.05)
                if not ready:
                    continue

                ch = sys.stdin.read(1)

                if ch == '\x1b':
                    rest = sys.stdin.read(2) if select.select([sys.stdin], [], [], 0.05)[0] else ''
                    ch = '\x1b' + rest

                new_twist = Twist()
                label, detail = '', ''

                if ch in ('w', 'W', '\x1b[A'):
                    new_twist.linear.x = self.linear
                    label, detail = 'FORWARD', f'{self.linear:.2f} m/s'
                elif ch in ('s', 'S', '\x1b[B'):
                    new_twist.linear.x = -self.linear
                    label, detail = 'BACKWARD', f'{self.linear:.2f} m/s'
                elif ch in ('a', 'A', '\x1b[D'):
                    new_twist.angular.z = self.angular
                    label, detail = 'TURN LEFT', f'{self.angular:.2f} rad/s'
                elif ch in ('d', 'D', '\x1b[C'):
                    new_twist.angular.z = -self.angular
                    label, detail = 'TURN RIGHT', f'{self.angular:.2f} rad/s'
                elif ch == ' ':
                    label = 'STOP'
                elif ch in ('+', '='):
                    self.linear = min(self.linear + 0.05, 0.50)
                    self.angular = min(self.angular + 0.10, 1.50)
                    label, detail = 'SPEED +', f'lin={self.linear:.2f}  ang={self.angular:.2f}'
                elif ch == '-':
                    self.linear = max(self.linear - 0.05, 0.05)
                    self.angular = max(self.angular - 0.10, 0.10)
                    label, detail = 'SPEED -', f'lin={self.linear:.2f}  ang={self.angular:.2f}'
                elif ch in ('m', 'M'):
                    self.save_map()
                    continue
                elif ch in ('q', 'Q', '\x03'):
                    self.save_map()
                    self.running = False
                    continue
                else:
                    continue

                with self._lock:
                    self._twist = new_twist

                self._status(label, detail)

        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def run(self):
        print(BANNER)
        print(f'  Map path : {BLD}{MAP_SAVE_PATH}.yaml / .pgm{RST}')
        print(f'  Linear   : {self.linear:.2f} m/s   Angular: {self.angular:.2f} rad/s\n')

        t = threading.Thread(target=self._key_thread, daemon=True)
        t.start()

        rate = rospy.Rate(PUBLISH_HZ)
        while self.running and not rospy.is_shutdown():
            with self._lock:
                self.pub.publish(self._twist)
            rate.sleep()

        self.pub.publish(Twist())
        t.join(timeout=2.0)

        print(f'\n\n{GRN}{BLD}Phase 1 complete.{RST}')
        if self.saved:
            print(f'  Map : {MAP_SAVE_PATH}.yaml  &  {MAP_SAVE_PATH}.pgm')
        else:
            print(f'  {YEL}WARNING: Map was NOT saved. Run rosrun map_server map_saver -f {MAP_SAVE_PATH}{RST}')
        print(f'\n  {CYN}→ Proceed to Phase 2{RST}\n')


if __name__ == '__main__':
    try:
        TeleopSlam().run()
    except rospy.ROSInterruptException:
        pass
