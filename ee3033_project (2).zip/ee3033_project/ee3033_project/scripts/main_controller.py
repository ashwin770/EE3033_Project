#!/usr/bin/env python2.7
import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Twist
from sensor_msgs.msg import CameraInfo
from darknet_ros_msgs.msg import BoundingBoxes
import math

class MainController:
    def __init__(self):
        rospy.init_node('main_controller', anonymous=True)

        self.target_class = rospy.get_param('~target_class', 'person')
        self.camera_width = rospy.get_param('~camera_width', 640)
        self.kp_turn = rospy.get_param('~kp_turn', 0.005)
        self.align_threshold = rospy.get_param('~align_threshold', 20) # pixels
        self.lost_timeout = rospy.get_param('~lost_timeout', 3.0) # seconds

        self.state = "EXPLORE" # EXPLORE, TRACKING, LOST, RETURN, DONE
        self.target_box = None
        self.last_detection_time = rospy.Time.now()
        self.last_seen_side = 0 # -1 left, 1 right
        
        # We need the start position to return to
        self.start_pose = None
        
        # Publishers and Subscribers
        self.cmd_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        self.bbox_sub = rospy.Subscriber('/darknet_ros/bounding_boxes', BoundingBoxes, self.bbox_callback)
        
        # Navigation client
        self.nav_client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        rospy.loginfo("Waiting for move_base action server...")
        self.nav_client.wait_for_server()
        rospy.loginfo("Connected to move_base server.")

    def bbox_callback(self, msg):
        for box in msg.bounding_boxes:
            if box.Class == self.target_class:
                self.target_box = box
                self.last_detection_time = rospy.Time.now()
                # Determine which side it's on for search direction if lost
                cx = (box.xmin + box.xmax) / 2.0
                if cx < self.camera_width / 2.0:
                    self.last_seen_side = 1 # turn left (+Z)
                else:
                    self.last_seen_side = -1 # turn right (-Z)
                return
        
        self.target_box = None

    def stop_robot(self):
        msg = Twist()
        self.cmd_pub.publish(msg)

    def run(self):
        rate = rospy.Rate(10) # 10 Hz
        
        while not rospy.is_shutdown():
            current_time = rospy.Time.now()
            
            if self.state == "EXPLORE":
                # Exploration is handled by a separate node or waypoint sender.
                # Here we just check for the target.
                if self.target_box is not None:
                    rospy.loginfo("Target detected! Stopping exploration and aligning.")
                    self.nav_client.cancel_all_goals()
                    self.stop_robot()
                    self.state = "TRACKING"
                    
            elif self.state == "TRACKING":
                if self.target_box is not None:
                    cx = (self.target_box.xmin + self.target_box.xmax) / 2.0
                    error_x = (self.camera_width / 2.0) - cx
                    
                    msg = Twist()
                    if abs(error_x) > self.align_threshold:
                        msg.angular.z = self.kp_turn * error_x
                        self.cmd_pub.publish(msg)
                    else:
                        rospy.loginfo("Target aligned and localized! Returning to start.")
                        self.stop_robot()
                        self.state = "RETURN"
                else:
                    # Check for timeout
                    if (current_time - self.last_detection_time).to_sec() > self.lost_timeout:
                        rospy.logwarn("Target lost! Entering search state.")
                        self.stop_robot()
                        self.state = "LOST"
                        
            elif self.state == "LOST":
                if self.target_box is not None:
                    rospy.loginfo("Target re-acquired! Resuming tracking.")
                    self.stop_robot()
                    self.state = "TRACKING"
                else:
                    # Spin slowly in the direction last seen
                    msg = Twist()
                    msg.angular.z = 0.3 * self.last_seen_side if self.last_seen_side != 0 else 0.3
                    self.cmd_pub.publish(msg)

            elif self.state == "RETURN":
                # Assuming starting point is origin (0,0) with 0 orientation (or map frame origin)
                rospy.loginfo("Sending goal to return to start (0,0).")
                goal = MoveBaseGoal()
                goal.target_pose.header.frame_id = "map"
                goal.target_pose.header.stamp = rospy.Time.now()
                goal.target_pose.pose.position.x = 0.0
                goal.target_pose.pose.position.y = 0.0
                goal.target_pose.pose.orientation.w = 1.0 # Facing forward
                
                self.nav_client.send_goal(goal)
                self.nav_client.wait_for_result()
                rospy.loginfo("Returned to start! Mission accomplished.")
                self.state = "DONE"
                
            elif self.state == "DONE":
                self.stop_robot()
                # Do nothing, mission is over

            rate.sleep()

if __name__ == '__main__':
    try:
        controller = MainController()
        controller.run()
    except rospy.ROSInterruptException:
        pass
