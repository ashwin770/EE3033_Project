#!/usr/bin/env python2.7
"""
Frontier-Based Autonomous Exploration Node

This node automatically drives the robot to unexplored areas of the map.
It works by:
  1. Reading the map published by gmapping (/map topic).
  2. Finding all "frontiers" -- cells on the edge between free space and unknown space.
  3. Picking the CLOSEST frontier to the robot's current position (smarter than random).
  4. Sending that frontier as a navigation goal to move_base.
  5. If the robot is stuck on a goal for too long, it cancels and picks the next closest one.
  6. When no more frontiers exist, the map is fully explored.
"""

import rospy
import actionlib
import math

from geometry_msgs.msg import PoseStamped
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseWithCovarianceStamped
from std_msgs.msg import Bool
from actionlib_msgs.msg import GoalStatus


class FrontierExplorer:
    def __init__(self):
        rospy.init_node('exploration_node')

        # --- Map Data ---
        self.map_data = []
        self.map_info = None

        # --- Robot Pose (from AMCL) ---
        self.robot_x = 0.0
        self.robot_y = 0.0
        self.pose_received = False

        # --- Goal Management ---
        # How long (seconds) to wait before giving up on a stuck goal
        self.goal_timeout = rospy.get_param('~goal_timeout', 20.0)
        self.goal_start_time = None
        self.current_goal_xy = None

        # Minimum distance (meters) to consider a new frontier
        # (avoids re-sending the same nearby goal repeatedly)
        self.min_frontier_dist = rospy.get_param('~min_frontier_dist', 0.3)

        # --- ROS Subscribers & Publishers ---
        rospy.Subscriber('/map', OccupancyGrid, self.map_callback)
        rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, self.pose_callback)

        self.complete_pub = rospy.Publisher('/exploration_complete', Bool, queue_size=1, latch=True)

        # --- Move Base Action Client ---
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        rospy.loginfo("[Explorer] Waiting for move_base action server...")
        self.client.wait_for_server()
        rospy.loginfo("[Explorer] Connected to move_base.")

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def map_callback(self, msg):
        """Store the latest occupancy grid."""
        self.map_data = list(msg.data)
        self.map_info = msg.info

    def pose_callback(self, msg):
        """Store the robot's latest estimated position from AMCL."""
        self.robot_x = msg.pose.pose.position.x
        self.robot_y = msg.pose.pose.position.y
        self.pose_received = True

    # ------------------------------------------------------------------
    # Frontier Detection
    # ------------------------------------------------------------------

    def get_frontiers(self):
        """
        Scan the occupancy grid and return a list of world-coordinate
        positions (wx, wy) that are frontiers (free cell adjacent to unknown).
        """
        if not self.map_data or self.map_info is None:
            return []

        width = self.map_info.width
        height = self.map_info.height
        resolution = self.map_info.resolution
        origin_x = self.map_info.origin.position.x
        origin_y = self.map_info.origin.position.y

        frontiers = []

        # Step size 2 to speed up search and reduce CPU usage
        for y in range(1, height - 1, 2):
            for x in range(1, width - 1, 2):
                idx = x + y * width
                if self.map_data[idx] == 0:  # Free space
                    # Check 4-way neighbours for unknown space (-1)
                    neighbours = [
                        idx - 1,
                        idx + 1,
                        idx - width,
                        idx + width,
                    ]
                    for n in neighbours:
                        if 0 <= n < len(self.map_data) and self.map_data[n] == -1:
                            # Convert grid cell to world coordinates
                            wx = x * resolution + origin_x
                            wy = y * resolution + origin_y
                            frontiers.append((wx, wy))
                            break

        return frontiers

    # ------------------------------------------------------------------
    # Goal Selection: Closest Frontier
    # ------------------------------------------------------------------

    def pick_closest_frontier(self, frontiers):
        """
        From the list of frontier world positions, return the one that is
        closest to the robot's current position.
        This is smarter than random selection because it minimises travel.
        """
        if not frontiers:
            return None

        best = None
        best_dist = float('inf')

        for (wx, wy) in frontiers:
            dist = math.sqrt((wx - self.robot_x) ** 2 + (wy - self.robot_y) ** 2)
            if dist < best_dist and dist > self.min_frontier_dist:
                best_dist = dist
                best = (wx, wy)

        return best  # Returns None if all frontiers are too close

    # ------------------------------------------------------------------
    # Send a Navigation Goal
    # ------------------------------------------------------------------

    def send_goal(self, x, y):
        """Send a MoveBaseGoal and record the time we started."""
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()
        goal.target_pose.pose.position.x = x
        goal.target_pose.pose.position.y = y
        goal.target_pose.pose.orientation.w = 1.0  # Face forward

        self.client.send_goal(goal)
        self.goal_start_time = rospy.Time.now()
        self.current_goal_xy = (x, y)
        rospy.loginfo("[Explorer] New goal -> x={:.2f}, y={:.2f}".format(x, y))

    # ------------------------------------------------------------------
    # Main Exploration Loop
    # ------------------------------------------------------------------

    def explore(self):
        """
        Main loop. Runs at 0.5 Hz (checks every 2 seconds to be gentle on CPU).

        Logic:
          - If not moving towards a goal -> find the closest frontier and go there.
          - If moving but stuck too long  -> cancel and find the next closest frontier.
          - If no frontiers remain        -> exploration is complete, publish flag and exit.
        """
        rate = rospy.Rate(0.5)  # 0.5 Hz = check every 2 seconds

        # Wait until we have map data and a robot pose before starting
        rospy.loginfo("[Explorer] Waiting for map and AMCL pose...")
        while not rospy.is_shutdown():
            if self.map_data and self.pose_received:
                break
            rospy.sleep(1.0)
        rospy.loginfo("[Explorer] Map and pose received. Starting frontier exploration!")

        while not rospy.is_shutdown():
            state = self.client.get_state()
            now = rospy.Time.now()

            goal_active = state in [GoalStatus.ACTIVE, GoalStatus.PENDING]

            # --- Check for stuck goal (timeout) ---
            if goal_active and self.goal_start_time is not None:
                elapsed = (now - self.goal_start_time).to_sec()
                if elapsed > self.goal_timeout:
                    rospy.logwarn(
                        "[Explorer] Goal timed out after {:.0f}s. Cancelling and picking new frontier.".format(elapsed)
                    )
                    self.client.cancel_goal()
                    self.goal_start_time = None
                    goal_active = False

            # --- Find and send a new goal if not currently driving ---
            if not goal_active:
                frontiers = self.get_frontiers()

                if not frontiers:
                    rospy.loginfo("[Explorer] No frontiers found. Map exploration complete!")
                    self.complete_pub.publish(Bool(data=True))
                    self.client.cancel_all_goals()
                    break

                target = self.pick_closest_frontier(frontiers)

                if target is None:
                    rospy.loginfo("[Explorer] All frontiers too close. Sleeping...")
                else:
                    self.send_goal(target[0], target[1])

            rate.sleep()

        rospy.loginfo("[Explorer] Exploration node finished.")


if __name__ == '__main__':
    try:
        explorer = FrontierExplorer()
        explorer.explore()
    except rospy.ROSInterruptException:
        pass
