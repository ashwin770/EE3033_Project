#!/usr/bin/env python
# -*- coding: utf-8 -*-

import math
import threading

import rospy
import actionlib
import tf

from geometry_msgs.msg import (Twist, PoseStamped, PoseWithCovarianceStamped, PointStamped, Quaternion)
from std_msgs.msg import String, Float32
from sensor_msgs.msg import Image
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import GoalStatus
from darknet_ros_msgs.msg import BoundingBoxes


class YoloObjectSearch(object):
    def __init__(self):
        rospy.init_node("yolo_object_search")

        # -----------------------------
        # Parameters
        # -----------------------------
        self.target_class = rospy.get_param("~target_class", "bottle")
        self.map_frame = rospy.get_param("~map_frame", "map")
        self.base_frame = rospy.get_param("~base_frame", "base_link")

        # Search movement
        self.sector_count = rospy.get_param("~sector_count", 8)
        self.move_step_distance = rospy.get_param("~move_step_distance", 1.0)

        # Step-scan behavior
        self.scan_hold_time = rospy.get_param("~scan_hold_time", 15.0)
        self.scan_step_angle_deg = rospy.get_param("~scan_step_angle_deg", 25.0)
        self.scan_rotate_speed = rospy.get_param("~scan_rotate_speed", 0.20)
        self.scan_timeout = rospy.get_param("~scan_timeout", 180.0)

        # YOLO thresholds
        self.search_confidence_min = rospy.get_param("~search_confidence_min", 0.35)
        self.align_confidence_min = rospy.get_param("~align_confidence_min", 0.40)
        self.detection_timeout = rospy.get_param("~detection_timeout", 1.0)

        # One-time alignment after detection
        self.centering_kp = rospy.get_param("~centering_kp", 0.0025)
        self.max_turn_speed = rospy.get_param("~max_turn_speed", 0.25)
        self.align_tolerance_ratio = rospy.get_param("~align_tolerance_ratio", 0.08)
        self.align_stable_cycles = rospy.get_param("~align_stable_cycles", 5)
        self.align_timeout = rospy.get_param("~align_timeout", 8.0)

        # Straight drive after identification
        self.forward_speed = rospy.get_param("~forward_speed", 0.06)

        # Front obstacle distance topic
        self.front_obstacle_topic = rospy.get_param("~front_obstacle_topic", "/front_obstacle_distance")
        self.stop_distance = rospy.get_param("~stop_distance", 0.45)

        # Fixed return pose: go back to 0,0,0 in map
        self.return_x = rospy.get_param("~return_x", 0.0)
        self.return_y = rospy.get_param("~return_y", 0.0)
        self.return_yaw = rospy.get_param("~return_yaw", 0.0)

        # -----------------------------
        # Internal state
        # -----------------------------
        self.home_pose = None
        self.home_received = False

        self.image_width = None
        self.image_height = None

        self.latest_target_box = None
        self.latest_detection_time = rospy.Time(0)

        self.latest_front_distance = None
        self.latest_front_distance_time = rospy.Time(0)

        self.scanned_sectors = set()
        self.search_cycle_index = 0
        self.mission_done = False
        self.target_locked = False

        self.lock = threading.Lock()

        # -----------------------------
        # Publishers
        # -----------------------------
        self.cmd_vel_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        self.status_pub = rospy.Publisher("/search_status", String, queue_size=10)
        self.object_location_pub = rospy.Publisher("/found_object_location", PointStamped, queue_size=1)

        # -----------------------------
        # Subscribers
        # -----------------------------
        rospy.Subscriber("/initialpose", PoseWithCovarianceStamped, self.initialpose_cb, queue_size=1)
        rospy.Subscriber("/darknet_ros/bounding_boxes", BoundingBoxes, self.bounding_boxes_cb, queue_size=1)
        rospy.Subscriber("/darknet_ros/detection_image", Image, self.image_cb, queue_size=1)
        rospy.Subscriber(self.front_obstacle_topic, Float32, self.front_obstacle_cb, queue_size=1)

        # -----------------------------
        # TF + move_base
        # -----------------------------
        self.tf_listener = tf.TransformListener()

        rospy.loginfo("Waiting for move_base server...")
        self.move_base_client = actionlib.SimpleActionClient("/move_base", MoveBaseAction)
        self.move_base_client.wait_for_server()
        rospy.loginfo("Connected to move_base.")

    # =========================================================
    # Callbacks
    # =========================================================
    def initialpose_cb(self, msg):
        with self.lock:
            self.home_pose = PoseStamped()
            self.home_pose.header.frame_id = self.map_frame
            self.home_pose.header.stamp = rospy.Time.now()
            self.home_pose.pose = msg.pose.pose
            self.home_received = True

        rospy.loginfo("Initial pose received: x=%.3f y=%.3f",
                      msg.pose.pose.position.x,
                      msg.pose.pose.position.y)

    def image_cb(self, msg):
        with self.lock:
            self.image_width = msg.width
            self.image_height = msg.height

    def bounding_boxes_cb(self, msg):
        best_box = None
        best_prob = -1.0

        for box in msg.bounding_boxes:
            cls = box.Class.strip().lower()
            prob = float(box.probability)

            if cls == self.target_class.lower() and prob >= self.search_confidence_min:
                if prob > best_prob:
                    best_prob = prob
                    best_box = box

        with self.lock:
            if best_box is not None:
                self.latest_target_box = best_box
                self.latest_detection_time = rospy.Time.now()

    def front_obstacle_cb(self, msg):
        with self.lock:
            self.latest_front_distance = float(msg.data)
            self.latest_front_distance_time = rospy.Time.now()

    # =========================================================
    # Helpers
    # =========================================================
    def publish_status(self, text):
        rospy.loginfo(text)
        self.status_pub.publish(String(data=text))

    def stop_robot(self):
        self.cmd_vel_pub.publish(Twist())

    def quaternion_from_yaw(self, yaw):
        q = tf.transformations.quaternion_from_euler(0.0, 0.0, yaw)
        quat = Quaternion()
        quat.x = q[0]
        quat.y = q[1]
        quat.z = q[2]
        quat.w = q[3]
        return quat

    def yaw_from_quaternion(self, q):
        quat = [q.x, q.y, q.z, q.w]
        _, _, yaw = tf.transformations.euler_from_quaternion(quat)
        return yaw

    def normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    def get_robot_pose(self):
        try:
            self.tf_listener.waitForTransform(
                self.map_frame, self.base_frame, rospy.Time(0), rospy.Duration(1.0)
            )
            trans, rot = self.tf_listener.lookupTransform(self.map_frame, self.base_frame, rospy.Time(0))

            pose = PoseStamped()
            pose.header.frame_id = self.map_frame
            pose.header.stamp = rospy.Time.now()
            pose.pose.position.x = trans[0]
            pose.pose.position.y = trans[1]
            pose.pose.position.z = trans[2]
            pose.pose.orientation.x = rot[0]
            pose.pose.orientation.y = rot[1]
            pose.pose.orientation.z = rot[2]
            pose.pose.orientation.w = rot[3]
            return pose
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            return None

    def build_goal(self, x, y, yaw):
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = self.map_frame
        goal.target_pose.header.stamp = rospy.Time.now()
        goal.target_pose.pose.position.x = x
        goal.target_pose.pose.position.y = y
        goal.target_pose.pose.position.z = 0.0
        goal.target_pose.pose.orientation = self.quaternion_from_yaw(yaw)
        return goal

    def current_detection_fresh(self):
        with self.lock:
            if self.latest_target_box is None:
                return False
            age = (rospy.Time.now() - self.latest_detection_time).to_sec()
            return age <= self.detection_timeout

    def get_latest_box(self):
        with self.lock:
            return self.latest_target_box

    def get_image_width(self):
        with self.lock:
            return self.image_width

    def bbox_center_x(self, box):
        return 0.5 * (box.xmin + box.xmax)

    def get_front_obstacle_distance(self):
        with self.lock:
            if self.latest_front_distance is None:
                return None
            age = (rospy.Time.now() - self.latest_front_distance_time).to_sec()
            if age > 1.0:
                return None
            return self.latest_front_distance

    def front_obstacle_detected(self):
        dist = self.get_front_obstacle_distance()
        if dist is None:
            return False
        return dist <= self.stop_distance

    # =========================================================
    # Rotation helpers
    # =========================================================
    def rotate_by_angle(self, angle_rad):
        if abs(angle_rad) < 1e-4:
            return True

        pose = self.get_robot_pose()
        if pose is None:
            return False

        start_yaw = self.yaw_from_quaternion(pose.pose.orientation)
        target_yaw = self.normalize_angle(start_yaw + angle_rad)

        twist = Twist()
        twist.angular.z = self.scan_rotate_speed if angle_rad > 0.0 else -self.scan_rotate_speed

        rate = rospy.Rate(25)

        while not rospy.is_shutdown():
            current_pose = self.get_robot_pose()
            if current_pose is None:
                self.stop_robot()
                return False

            current_yaw = self.yaw_from_quaternion(current_pose.pose.orientation)
            err = self.normalize_angle(target_yaw - current_yaw)

            if abs(err) < math.radians(2.0):
                self.stop_robot()
                rospy.sleep(0.2)
                return True

            self.cmd_vel_pub.publish(twist)
            rate.sleep()

        self.stop_robot()
        return False

    # =========================================================
    # Navigation helpers
    # =========================================================
    def send_goal_and_watch_detection(self, goal, name="goal"):
        self.publish_status("Navigating to {}".format(name))
        self.move_base_client.send_goal(goal)

        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            state = self.move_base_client.get_state()

            if self.current_detection_fresh() and not self.target_locked:
                rospy.loginfo("Target detected during navigation, cancelling goal.")
                self.move_base_client.cancel_goal()
                return "detected"

            if state == GoalStatus.SUCCEEDED:
                return "succeeded"

            if state in [GoalStatus.ABORTED, GoalStatus.REJECTED, GoalStatus.PREEMPTED, GoalStatus.RECALLED]:
                return "failed"

            rate.sleep()

    # =========================================================
    # Search phase
    # =========================================================
    def wait_for_initial_pose(self):
        self.publish_status("Waiting for 2D Pose Estimate from RViz...")
        rate = rospy.Rate(5)

        while not rospy.is_shutdown() and not self.home_received:
            rate.sleep()

        self.publish_status("Initial pose received. Search started.")

    def rotate_and_scan(self):
        self.stop_robot()
        rospy.sleep(0.2)

        self.publish_status("Step-scan started for '{}'".format(self.target_class))

        start_time = rospy.Time.now()
        step_angle_rad = math.radians(self.scan_step_angle_deg)
        max_steps = max(1, int(round(360.0 / max(self.scan_step_angle_deg, 1.0))))

        for step_idx in range(max_steps):
            if rospy.is_shutdown():
                break

            self.stop_robot()
            self.publish_status(
                "Holding scan position {}/{} for {:.1f} seconds.".format(
                    step_idx + 1, max_steps, self.scan_hold_time
                )
            )

            wait_start = rospy.Time.now()
            rate = rospy.Rate(10)

            while not rospy.is_shutdown():
                if self.current_detection_fresh():
                    self.stop_robot()
                    self.publish_status("Target detected while holding scan position.")
                    self.target_locked = True
                    return True

                if (rospy.Time.now() - wait_start).to_sec() >= self.scan_hold_time:
                    break

                if (rospy.Time.now() - start_time).to_sec() >= self.scan_timeout:
                    break

                rate.sleep()

            if self.current_detection_fresh():
                self.stop_robot()
                self.publish_status("Target detected during scan.")
                self.target_locked = True
                return True

            if (rospy.Time.now() - start_time).to_sec() >= self.scan_timeout:
                break

            if step_idx < max_steps - 1:
                self.publish_status(
                    "Rotating by {:.1f} degrees to next scan position.".format(self.scan_step_angle_deg)
                )
                ok = self.rotate_by_angle(step_angle_rad)
                if not ok:
                    self.stop_robot()
                    return False

        self.stop_robot()
        return False

    def choose_untried_direction(self):
        all_sectors = list(range(self.sector_count))
        untried = [s for s in all_sectors if s not in self.scanned_sectors]

        if not untried:
            untried = all_sectors
            self.scanned_sectors.clear()

        sector = untried[self.search_cycle_index % len(untried)]
        self.search_cycle_index += 1

        angle = -math.pi + sector * (2.0 * math.pi / self.sector_count)
        return sector, angle

    def move_to_next_search_area(self):
        pose = self.get_robot_pose()
        if pose is None:
            return "failed"

        sector, rel_angle = self.choose_untried_direction()
        self.scanned_sectors.add(sector)

        current_yaw = self.yaw_from_quaternion(pose.pose.orientation)
        target_yaw = self.normalize_angle(current_yaw + rel_angle)

        x0 = pose.pose.position.x
        y0 = pose.pose.position.y

        x1 = x0 + self.move_step_distance * math.cos(target_yaw)
        y1 = y0 + self.move_step_distance * math.sin(target_yaw)

        self.publish_status("Object not found. Moving to another search area.")
        goal = self.build_goal(x1, y1, target_yaw)
        return self.send_goal_and_watch_detection(goal, "next search area")

    # =========================================================
    # Post-detection phase
    # =========================================================
    def rotate_to_face_object_once(self):
        self.publish_status("Target identified. Aligning once to face it.")

        start_time = rospy.Time.now()
        rate = rospy.Rate(15)
        stable_count = 0

        while not rospy.is_shutdown():
            if (rospy.Time.now() - start_time).to_sec() > self.align_timeout:
                self.stop_robot()
                self.publish_status("Alignment timeout reached. Proceeding forward anyway.")
                return True

            box = self.get_latest_box()
            img_w = self.get_image_width()

            if box is None or img_w is None or not self.current_detection_fresh():
                self.stop_robot()
                self.publish_status("Target was identified earlier. Proceeding forward without more scanning.")
                return True

            if float(box.probability) < self.align_confidence_min:
                rate.sleep()
                continue

            center_x = self.bbox_center_x(box)
            error_x = center_x - (img_w / 2.0)

            if abs(error_x) < self.align_tolerance_ratio * img_w:
                stable_count += 1
                self.stop_robot()
                if stable_count >= self.align_stable_cycles:
                    self.publish_status("Target aligned. Now switching to straight drive.")
                    return True
            else:
                stable_count = 0
                angular_z = -self.centering_kp * error_x
                angular_z = max(-self.max_turn_speed, min(self.max_turn_speed, angular_z))

                cmd = Twist()
                cmd.angular.z = angular_z
                self.cmd_vel_pub.publish(cmd)

            rate.sleep()

        self.stop_robot()
        return True

    def drive_straight_until_front_obstacle(self):
        self.publish_status("Driving straight until a real front obstacle is detected.")

        rate = rospy.Rate(15)

        while not rospy.is_shutdown():
            if self.front_obstacle_detected():
                self.stop_robot()
                rospy.sleep(0.4)
                self.publish_status("Front obstacle detected. Stopping at target.")
                self.report_object_location()
                return True

            cmd = Twist()
            cmd.linear.x = self.forward_speed
            cmd.angular.z = 0.0
            self.cmd_vel_pub.publish(cmd)
            rate.sleep()

        self.stop_robot()
        return False

    def report_object_location(self):
        pose = self.get_robot_pose()
        if pose is None:
            rospy.logwarn("Cannot report object location: no robot pose.")
            return False

        point = PointStamped()
        point.header.frame_id = self.map_frame
        point.header.stamp = rospy.Time.now()
        point.point.x = pose.pose.position.x
        point.point.y = pose.pose.position.y
        point.point.z = 0.0

        self.object_location_pub.publish(point)

        self.publish_status(
            "FOUND '{}' at map position x={:.3f}, y={:.3f}".format(
                self.target_class,
                point.point.x,
                point.point.y
            )
        )
        return True

    def return_home(self):
        goal = self.build_goal(self.return_x, self.return_y, self.return_yaw)

        self.publish_status(
            "Returning to fixed pose x={:.3f}, y={:.3f}, yaw={:.3f}".format(
                self.return_x, self.return_y, self.return_yaw
            )
        )

        result = self.send_goal_and_watch_detection(goal, "return pose")

        if result == "succeeded":
            self.publish_status("Returned to fixed pose successfully.")
            return True

        rospy.logwarn("Return to fixed pose failed.")
        return False

    # =========================================================
    # Mission flow
    # =========================================================
    def handle_detected_target(self):
        self.target_locked = True

        aligned = self.rotate_to_face_object_once()
        if not aligned:
            self.publish_status("Alignment incomplete, but target already identified. Proceeding forward anyway.")

        reached = self.drive_straight_until_front_obstacle()
        if not reached:
            self.publish_status("Could not confirm stop condition.")
            return False

        self.return_home()
        self.publish_status("Mission complete.")
        self.mission_done = True
        return True

    def run(self):
        self.wait_for_initial_pose()

        rate = rospy.Rate(2)

        while not rospy.is_shutdown() and not self.mission_done:
            if self.target_locked:
                self.handle_detected_target()
                break

            found = self.rotate_and_scan()
            if found:
                self.handle_detected_target()
                break

            if not self.target_locked:
                move_result = self.move_to_next_search_area()
                if move_result == "detected":
                    self.target_locked = True
                    self.handle_detected_target()
                    break

            rate.sleep()

        self.stop_robot()


if __name__ == "__main__":
    try:
        node = YoloObjectSearch()
        node.run()
    except rospy.ROSInterruptException:
        pass
