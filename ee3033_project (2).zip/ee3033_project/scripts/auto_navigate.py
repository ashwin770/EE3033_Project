#!/usr/bin/env python3
"""
auto_navigate.py  —  Phase 2: Autonomous Navigation + Object Detection + Return
================================================================================
Reads the map saved in Phase 1, generates a lawnmower sweep automatically,
navigates every waypoint, detects the target object via darknet_ros, then
returns the robot to its starting position — fully hands-free.

Usage
-----
  rosrun full_demo auto_navigate.py [--map PATH] [--target CLASS] [--confidence F]

Examples
--------
  rosrun full_demo auto_navigate.py --target bottle
  rosrun full_demo auto_navigate.py --target person  --confidence 0.60
  rosrun full_demo auto_navigate.py --map ~/my_map.yaml --target cup

Supported YOLO classes (examples):
  person, bottle, cup, chair, laptop, cell phone, backpack, book,
  dog, cat, orange, apple, suitcase, umbrella, vase …

Prerequisites (before running this script)
------------------------------------------
  Robot terminal 1:
    $ roslaunch turn_on_wheeltec_robot navigation.launch

  Robot terminal 2:
    $ roslaunch usb_cam usb_cam-test.launch

  Laptop terminal 1 (image republisher):
    $ rosrun image_transport republish compressed \\
        in:=/usb_cam/image_raw raw \\
        out:=/usb_cam/image_raw_uncompressed

  Laptop terminal 2 (darknet_ros):
    $ source ~/catkin_ws/devel/setup.bash
    $ roslaunch darknet_ros darknet_ros.launch \\
        image:=/usb_cam/image_raw_uncompressed \\
        camera_info:=/usb_cam/camera_info

  Laptop terminal 3 (THIS script):
    $ rosrun full_demo auto_navigate.py --target <class>
"""

import os
import sys
import math
import argparse
import threading

import rospy
import actionlib
import yaml
import numpy as np

try:
    from PIL import Image as PILImage
except ImportError:
    sys.exit('[ERROR] Pillow not found.  Run:  pip3 install Pillow')

from geometry_msgs.msg import PoseWithCovarianceStamped, Twist
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import GoalStatus

# ─────────────────────────────────────────────────────────────────
DEFAULT_MAP        = os.path.expanduser('~/demo_map.yaml')
DEFAULT_TARGET     = 'person'
DEFAULT_CONFIDENCE = 0.65
WAYPOINT_SPACING   = 0.50   # metres — grid resolution of the sweep
NAV_TIMEOUT        = 25.0   # seconds per waypoint before skipping
RETURN_TIMEOUT     = 90.0   # seconds allowed for the return trip
INIT_POSE_X        = 0.0    # robot start in map frame
INIT_POSE_Y        = 0.0
INIT_POSE_THETA    = 0.0    # radians
# ─────────────────────────────────────────────────────────────────

# ANSI colours
GRN  = '\033[92m'
YEL  = '\033[93m'
RED  = '\033[91m'
CYN  = '\033[96m'
MAG  = '\033[95m'
BLD  = '\033[1m'
RST  = '\033[0m'

BANNER = f"""
{CYN}{BLD}╔══════════════════════════════════════════════════╗
║   AUTO NAVIGATE + DETECT + RETURN  —  Phase 2    ║
╚══════════════════════════════════════════════════╝{RST}
"""

def _log(colour, tag, msg):
    rospy.loginfo(f'{colour}{BLD}[{tag}]{RST}  {msg}')

def _warn(msg):
    rospy.logwarn(f'{YEL}{BLD}[WARN]{RST}  {msg}')

def _err(msg):
    rospy.logerr(f'{RED}{BLD}[ERR ]{RST}  {msg}')


# ══════════════════════════════════════════════════════════════════
class AutoNavigator:
    """Handles the full Phase-2 pipeline."""

    def __init__(self, map_yaml: str, target_class: str, min_conf: float):
        rospy.init_node('auto_navigator', anonymous=True)

        self.map_yaml    = map_yaml
        self.target      = target_class
        self.min_conf    = min_conf

        # ── Runtime state ──────────────────────────────────────
        self.current_pose  = None
        self.detected      = False
        self.detected_pose = None
        self._det_lock     = threading.Lock()
        
        self.target_box    = None
        self.target_lost_time = None
        self.camera_width  = 640

        self.start_x     = INIT_POSE_X
        self.start_y     = INIT_POSE_Y
        self.start_theta = INIT_POSE_THETA

        # ── Publishers ─────────────────────────────────────────
        self.init_pub = rospy.Publisher(
            '/initialpose', PoseWithCovarianceStamped, queue_size=1, latch=True)
        self.vel_pub  = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

        # ── Subscribers ────────────────────────────────────────
        rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, self._pose_cb)
        self._subscribe_detection()

        # ── move_base action client ────────────────────────────
        _log(CYN, 'NAV', 'Connecting to move_base …')
        self.mb = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        connected = self.mb.wait_for_server(rospy.Duration(30.0))
        if not connected:
            _err('move_base not available after 30 s. Is navigation.launch running?')
            sys.exit(1)
        _log(GRN, 'NAV', 'move_base ready.')

    # ── Detection subscription ─────────────────────────────────

    def _subscribe_detection(self):
        try:
            from darknet_ros_msgs.msg import BoundingBoxes
            rospy.Subscriber(
                '/darknet_ros/bounding_boxes',
                BoundingBoxes,
                self._detect_cb)
            _log(GRN, 'DET', 'Subscribed to /darknet_ros/bounding_boxes')
        except ImportError:
            _warn('darknet_ros_msgs not importable — detection disabled.')
            _warn('Source your catkin_ws:  source ~/catkin_ws/devel/setup.bash')

    # ── Callbacks ──────────────────────────────────────────────

    def _pose_cb(self, msg: PoseWithCovarianceStamped):
        self.current_pose = msg.pose.pose

    def _detect_cb(self, msg):
        """Called every time darknet_ros publishes bounding boxes."""
        found_target = None
        for box in msg.bounding_boxes:
            if box.Class == self.target and box.probability >= self.min_conf:
                found_target = box
                break

        with self._det_lock:
            if not self.detected and found_target:
                rospy.logwarn(
                    f'\n{MAG}{BLD}'
                    f'★★★  TARGET DETECTED: {found_target.Class}  '
                    f'(conf={found_target.probability:.2f})  ★★★'
                    f'{RST}\n')
                self.detected = True
                if self.current_pose:
                    self.detected_pose = self.current_pose
                    p = self.detected_pose.position
                    _log(MAG, 'DET', f'Robot location at detection: x={p.x:.3f}  y={p.y:.3f}')
                # Cancel current navigation goal
                self.mb.cancel_all_goals()
                
            if found_target:
                self.target_box = found_target
                self.target_lost_time = None
            elif self.detected and self.target_box is not None and self.target_lost_time is None:
                self.target_lost_time = rospy.Time.now()

    # ── Initial pose ───────────────────────────────────────────

    def publish_initial_pose(self):
        x, y, theta = self.start_x, self.start_y, self.start_theta
        _log(CYN, 'INIT',
             f'Publishing initial pose  x={x:.2f}  y={y:.2f}  '
             f'θ={math.degrees(theta):.1f}°')

        msg = PoseWithCovarianceStamped()
        msg.header.frame_id = 'map'
        msg.header.stamp    = rospy.Time.now()
        msg.pose.pose.position.x    = x
        msg.pose.pose.position.y    = y
        msg.pose.pose.orientation.z = math.sin(theta / 2.0)
        msg.pose.pose.orientation.w = math.cos(theta / 2.0)

        cov = [0.0] * 36
        cov[0]  = 0.25    # σ²x
        cov[7]  = 0.25    # σ²y
        cov[35] = 0.0685  # σ²yaw
        msg.pose.covariance = cov

        self.init_pub.publish(msg)
        rospy.sleep(2.0)   # give AMCL time to converge

    # ── Map loading ────────────────────────────────────────────

    def _load_map(self):
        """Returns (numpy array, resolution, origin_x, origin_y)."""
        if not os.path.exists(self.map_yaml):
            _err(f'Map YAML not found: {self.map_yaml}')
            _err(f'Did Phase 1 complete with  M / Q  pressed?')
            sys.exit(1)

        with open(self.map_yaml) as f:
            meta = yaml.safe_load(f)

        res    = meta['resolution']           # m/pixel
        origin = meta['origin']               # [ox, oy, otheta]
        pgm    = self.map_yaml.replace('.yaml', '.pgm')

        if not os.path.exists(pgm):
            _err(f'Map PGM not found: {pgm}')
            sys.exit(1)

        arr = np.array(PILImage.open(pgm))
        _log(CYN, 'MAP',
             f'Loaded  {arr.shape[1]}×{arr.shape[0]} px  '
             f'res={res} m/px  origin=({origin[0]:.2f},{origin[1]:.2f})')
        return arr, res, origin[0], origin[1]

    # ── Waypoint generation ────────────────────────────────────

    def generate_waypoints(self, spacing: float = WAYPOINT_SPACING):
        """
        Lawnmower sweep over the map's free space.

        Free  = pixel > 200  (white ~254)
        Occ   = pixel < 50   (black  ~0)
        Unk   = 50–200       (gray  ~205)

        A 5×5 safety patch is checked so waypoints are not placed
        next to obstacle cells.
        """
        arr, res, ox, oy = self._load_map()
        H, W  = arr.shape
        step  = max(1, int(spacing / res))

        waypoints = []
        rows      = list(range(step, H - step, step))
        go_right  = True

        for row in rows:
            cols = list(range(step, W - step, step))
            if not go_right:
                cols = list(reversed(cols))

            for col in cols:
                # 5×5 neighbourhood must be entirely free
                r0, r1 = max(0, row - 2), min(H, row + 3)
                c0, c1 = max(0, col - 2), min(W, col + 3)
                patch  = arr[r0:r1, c0:c1]

                if patch.min() > 200:                 # free
                    wx = ox + col * res
                    wy = oy + (H - 1 - row) * res     # flip row→y
                    waypoints.append((wx, wy))

            go_right = not go_right

        _log(GRN, 'MAP',
             f'Generated {len(waypoints)} waypoints  '
             f'(spacing={spacing} m, step={step} px)')
        return waypoints

    # ── Navigation ─────────────────────────────────────────────

    def search_look_around(self):
        """Quickly pan the camera left and right to sweep for targets."""
        _log(CYN, 'NAV', 'Panning to scan surroundings...')
        msg = Twist()
        rate = rospy.Rate(10)
        
        # Pan Left
        msg.angular.z = 1.2
        end_time = rospy.Time.now() + rospy.Duration(1.0)
        while rospy.Time.now() < end_time and not rospy.is_shutdown():
            if self.detected: return
            self.vel_pub.publish(msg)
            rate.sleep()
            
        # Pan Right
        msg.angular.z = -1.2
        end_time = rospy.Time.now() + rospy.Duration(2.0)
        while rospy.Time.now() < end_time and not rospy.is_shutdown():
            if self.detected: return
            self.vel_pub.publish(msg)
            rate.sleep()
            
        # Return to center
        msg.angular.z = 1.2
        end_time = rospy.Time.now() + rospy.Duration(1.0)
        while rospy.Time.now() < end_time and not rospy.is_shutdown():
            if self.detected: return
            self.vel_pub.publish(msg)
            rate.sleep()
            
        self.vel_pub.publish(Twist())

    def _send_goal(self, x: float, y: float,
                   theta: float = 0.0,
                   timeout: float = NAV_TIMEOUT) -> bool:
        """Send one move_base goal; return True if SUCCEEDED."""
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = 'map'
        goal.target_pose.header.stamp    = rospy.Time.now()
        goal.target_pose.pose.position.x    = x
        goal.target_pose.pose.position.y    = y
        goal.target_pose.pose.orientation.z = math.sin(theta / 2.0)
        goal.target_pose.pose.orientation.w = math.cos(theta / 2.0)

        self.mb.send_goal(goal)
        finished = self.mb.wait_for_result(rospy.Duration(timeout))

        if not finished:
            _warn(f'Timeout ({timeout:.0f}s) at ({x:.2f},{y:.2f}) — skipping.')
            self.mb.cancel_goal()
            return False

        return self.mb.get_state() == GoalStatus.SUCCEEDED

    def drive_towards_target(self):
        _log(CYN, 'TRACK', 'Initiating visual servoing to drive towards target...')
        rate = rospy.Rate(10)
        
        kp_turn = 0.02
        kp_forward = 0.20
        target_box_width = 180 # Stop if the box fills a good portion of the screen
        
        while not rospy.is_shutdown():
            with self._det_lock:
                box = self.target_box
                lost_time = self.target_lost_time

            msg = Twist()
            
            if lost_time is not None:
                elapsed = (rospy.Time.now() - lost_time).to_sec()
                if elapsed > 3.0:
                    _log(YEL, 'TRACK', 'Target lost for over 3 seconds. Giving up tracking.')
                    break
                else:
                    self.vel_pub.publish(msg)
                    rate.sleep()
                    continue

            if box is not None:
                bw = box.xmax - box.xmin
                cx = (box.xmin + box.xmax) / 2.0
                error_x = (self.camera_width / 2.0) - cx
                
                if abs(error_x) > 20:
                    msg.angular.z = kp_turn * error_x
                    
                if bw < target_box_width:
                    msg.linear.x = kp_forward
                else:
                    _log(GRN, 'TRACK', 'Reached target object (box size threshold met)!')
                    self.vel_pub.publish(Twist())
                    break
                    
                self.vel_pub.publish(msg)
            rate.sleep()
            
        self.vel_pub.publish(Twist()) # Force stop when done
        rospy.sleep(1.0)

    def return_to_start(self):
        _log(CYN, 'NAV',
             f'Returning to start  ({self.start_x:.2f}, {self.start_y:.2f}) …')
        ok = self._send_goal(self.start_x, self.start_y,
                              self.start_theta, RETURN_TIMEOUT)
        if ok:
            _log(GRN, 'NAV', 'Reached starting position ✓')
        else:
            _warn('Could not fully reach start — stopping here.')
        self.vel_pub.publish(Twist())   # hard stop

    # ── Main pipeline ──────────────────────────────────────────

    def run(self):
        print(BANNER)
        _log(CYN, 'CONF', f'Map        : {self.map_yaml}')
        _log(CYN, 'CONF', f'Target     : {self.target}')
        _log(CYN, 'CONF', f'Min conf   : {self.min_conf}')
        _log(CYN, 'CONF', f'WP spacing : {WAYPOINT_SPACING} m')

        # 1 ── Initial pose → AMCL converges
        self.publish_initial_pose()

        # 2 ── Build waypoint list from map
        waypoints = self.generate_waypoints()
        if not waypoints:
            _err('No valid waypoints generated.  Check map file.')
            return

        _log(GRN, 'NAV',
             f'Starting autonomous sweep  ({len(waypoints)} waypoints) …')
        print(f'\n  {YEL}Robot is now navigating autonomously.{RST}\n')

        # 3 ── Navigate waypoints  (stop early if object detected)
        for i, (wx, wy) in enumerate(waypoints):
            if rospy.is_shutdown():
                break
            if self.detected:
                _log(YEL, 'NAV', 'Object detected — aborting sweep.')
                break
                
            # Calculate theta towards the *next* waypoint so the robot faces its path
            if i < len(waypoints) - 1:
                nx, ny = waypoints[i+1]
                theta = math.atan2(ny - wy, nx - wx)
            else:
                theta = 0.0

            rospy.loginfo(
                f'{CYN}[NAV]{RST}  WP {i+1:4d}/{len(waypoints)}'
                f'  →  ({wx:+.2f}, {wy:+.2f})')
            self._send_goal(wx, wy, theta=theta, timeout=NAV_TIMEOUT)
            
            if not self.detected:
                self.search_look_around()

        # 4 ── Attempt driving towards object if found
        if self.detected:
            self.drive_towards_target()

        # 5 ── Summary
        sep = '═' * 50
        if self.detected:
            print(f'\n{MAG}{BLD}{sep}')
            print(f'  OBJECT DETECTED : {self.target}')
            if self.detected_pose:
                p = self.detected_pose.position
                print(f'  Robot pos       : x={p.x:.3f}  y={p.y:.3f}')
            print(f'{sep}{RST}\n')
        else:
            print(f'\n{YEL}Target "{self.target}" was not found during sweep.{RST}\n')

        # 6 ── Return to starting position
        self.return_to_start()

        print(f'\n{GRN}{BLD}Phase 2 complete.  Demo finished!{RST}\n')


# ── Entry point ────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(
        description='Phase 2: Autonomous navigation + object detection + return')
    p.add_argument('--map', default=DEFAULT_MAP,
                   help=f'Path to map .yaml  (default: {DEFAULT_MAP})')
    p.add_argument('--target', default=DEFAULT_TARGET,
                   help='YOLO class name to detect  (default: person)')
    p.add_argument('--confidence', type=float, default=DEFAULT_CONFIDENCE,
                   help=f'Min detection confidence  (default: {DEFAULT_CONFIDENCE})')
    args, _ = p.parse_known_args()
    return args


if __name__ == '__main__':
    args = parse_args()
    try:
        AutoNavigator(args.map, args.target, args.confidence).run()
    except rospy.ROSInterruptException:
        pass
