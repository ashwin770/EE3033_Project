# EE3033 Project — Autonomous Maze Exploration

## System Architecture

```
┌──────────────────────────────────────┐     Wi-Fi      ┌─────────────────────────────┐
│           UBUNTU PC (ROS Master)     │◄──────────────►│  BALANCING CAR (ROS Nodes)  │
│                                      │                 │                             │
│  • gmapping / AMCL / move_base       │                 │  • Robot base driver        │
│  • darknet_ros (YOLO detection)      │                 │  • /cmd_vel subscriber      │
│  • main_controller.py                │                 │  • /scan  (LIDAR)           │
│  • exploration.py                    │                 │  • /odom  (wheel odometry)  │
│  • RViz                              │                 │  • usb_cam (camera)         │
└──────────────────────────────────────┘                 └─────────────────────────────┘
```

**ROS Master runs on the Ubuntu PC.** The car connects to it over Wi-Fi.

---

## Package Contents

| File | Purpose |
|---|---|
| `scripts/exploration.py` | Autonomous frontier-based exploration (drives itself to unmapped areas) |
| `scripts/main_controller.py` | State-machine brain: EXPLORE → TRACKING → RETURN → DONE |
| `launch/mapping.launch` | Stage 1 only — manual SLAM map building |
| `launch/navigation.launch` | Loads saved map + AMCL + move_base |
| `launch/project_main.launch` | **Main demo launch** — runs everything |
| `param/*.yaml` | Costmap and planner configuration |
| `rviz/ee3033_project.rviz` | Pre-configured RViz layout |

---

## Prerequisites

### Ubuntu PC
- Ubuntu 18.04 + **ROS Melodic**, or Ubuntu 20.04 + **ROS Noetic**
- A ROS workspace at `~/catkin_ws`
- `darknet_ros` already placed in `~/catkin_ws/src/darknet_ros`

### On the Robot (Car)
- ROS installed and the robot's base driver running
- Camera publishing to `/usb_cam/image_raw` (or your camera topic)
- LIDAR publishing to `/scan`
- Odometry publishing to `/odom`
- `ROS_MASTER_URI` pointing to the Ubuntu PC

---

## One-Time Setup (Do This Once)

### 1 — Copy Project into Workspace

```bash
mkdir -p ~/catkin_ws/src
cp -r ~/Desktop/ee3033_project ~/catkin_ws/src/
```

### 2 — Install Required ROS Packages (Ubuntu PC)

```bash
sudo apt-get update && sudo apt-get install -y \
  ros-$ROS_DISTRO-move-base \
  ros-$ROS_DISTRO-amcl \
  ros-$ROS_DISTRO-map-server \
  ros-$ROS_DISTRO-gmapping \
  ros-$ROS_DISTRO-teleop-twist-keyboard \
  ros-$ROS_DISTRO-usb-cam
```

### 3 — Mark Scripts as Executable

```bash
chmod +x ~/catkin_ws/src/ee3033_project/scripts/*.py
```

### 3b — Install the `tf` Python package (needed by auto_mapper)

```bash
sudo apt-get install -y ros-$ROS_DISTRO-tf
```

### 4 — Create Map Save Folder

```bash
mkdir -p ~/catkin_ws/src/ee3033_project/maps
```

### 5 — Build the Workspace

```bash
cd ~/catkin_ws && catkin_make
```

You should see `[100%] Built target ...` with no errors.

### 6 — Source the Workspace

Do this **in every new terminal you open**:

```bash
source ~/catkin_ws/devel/setup.bash
```

> **Tip:** Add it permanently so you never have to type it again:
> ```bash
> echo "source ~/catkin_ws/devel/setup.bash" >> ~/.bashrc && source ~/.bashrc
> ```

---

## Network Setup — PC ↔ Robot

> **Do this every time before running anything.**

On the **Ubuntu PC**, find your IP address:
```bash
hostname -I
# e.g. 192.168.1.100
```

On the **Ubuntu PC** (set in `~/.bashrc` or in each terminal):
```bash
export ROS_MASTER_URI=http://localhost:11311
export ROS_IP=192.168.1.100      # ← your PC's IP
```

On the **Robot**, in every terminal:
```bash
export ROS_MASTER_URI=http://192.168.1.100:11311   # ← PC's IP
export ROS_IP=192.168.1.50                          # ← robot's IP
```

Test the connection — on the PC run `roscore`, then on the robot run:
```bash
rostopic list   # should show ROS topics from the PC
```

---

## Stage 1: Build the Map — FULLY AUTOMATIC (Before the Demo)

> The **target object must NOT be in the sandbox** during this stage.

The robot will drive itself around the entire environment, build the map with gmapping, and **save it automatically** when done. No keyboard driving needed.

### Start the Robot Nodes First
Make sure the robot's base driver and LIDAR are running (see [Network Setup](#network-setup----pc--robot) above).

### Terminal 1 (PC) — Start Automatic SLAM Mapping

```bash
roslaunch ee3033_project mapping.launch
```

This starts:
- **gmapping** — SLAM map builder (reads `/scan`, publishes `/map` and `map→base_link` TF)
- **auto_mapper.py** — autonomously drives the robot to frontier areas to build the full map
- **usb_cam** — camera node

The robot will move by itself. Watch the terminal for `[AutoMapper]` log messages.

### Terminal 2 (PC) — Watch the Map Being Built (Optional)

```bash
rviz -d ~/catkin_ws/src/ee3033_project/rviz/ee3033_project.rviz
```

### Wait for Completion

When the map is complete, you will see in Terminal 1:
```
[AutoMapper] No frontiers left — map is complete!
[AutoMapper] Map saved successfully!
```

The map is saved automatically to:
```
~/catkin_ws/src/ee3033_project/maps/sandbox_map.yaml
~/catkin_ws/src/ee3033_project/maps/sandbox_map.pgm
```

**Stop mapping:** Press `Ctrl+C` in Terminal 1 after you see the success messages.

---

## Stage 2: Autonomous Exploration & Target Finding (The Demo)

> **Before starting:** Place the target object randomly in the sandbox.

### What to Run on the Robot

On the robot, start the robot's base driver and sensor nodes (exact commands depend on your car model). Typically:

```bash
# Terminal on Robot — start base driver (publishes /odom and subscribes /cmd_vel)
roslaunch <your_robot_package> bringup.launch

# Terminal on Robot — start LIDAR (publishes /scan)
roslaunch rplidar_ros rplidar.launch
```

> These must be running **before** you launch anything on the PC.

### What to Run on the Ubuntu PC

Everything launches with **one command**:

```bash
roslaunch ee3033_project project_main.launch
```

This starts all of the following automatically:
1. **usb_cam** — camera driver (publishes `/usb_cam/image_raw`)
2. **map_server** — loads `maps/sandbox_map.yaml`
3. **AMCL** — localises the robot on the saved map
4. **move_base** — plans collision-free paths
5. **AMCL initial pose** — seeds localization at origin `(0,0)` automatically
6. **darknet_ros** — YOLO object detection on the camera feed
7. **main_controller.py** — state machine brain
8. **exploration.py** — autonomous frontier explorer

#### Watch in RViz (separate terminal):
```bash
rviz -d ~/catkin_ws/src/ee3033_project/rviz/ee3033_project.rviz
```

---

## How the Robot Behaves

```
[EXPLORE] ──(target detected)──► [TRACKING] ──(target centred)──► [RETURN] ──► [DONE]
            ◄──(3s timeout)──── [LOST] ─────(target re-found)──►
```

| State | What the robot is doing |
|---|---|
| **EXPLORE** | Frontier explorer drives to the nearest unexplored map area |
| **TRACKING** | Target spotted — stops navigating, rotates to centre target in camera |
| **LOST** | Target gone >3s — slowly spins in the last known direction |
| **RETURN** | Target centred — navigates back to `(0, 0)` home |
| **DONE** | Mission complete, robot stops |

---

## Changing the Target Object

Edit `launch/project_main.launch` and change:
```xml
<param name="target_class" value="person" />
```
to any [YOLO COCO class](https://github.com/AlexeyAB/darknet/blob/master/data/coco.names) e.g. `bottle`, `chair`, `cup`.

---

## Useful Monitoring Commands

Open a new sourced terminal and run any of these:

```bash
# See detected objects and bounding boxes
rostopic echo /darknet_ros/bounding_boxes

# See velocity commands going to the robot
rostopic echo /cmd_vel

# See robot localization on the map
rostopic echo /amcl_pose

# Check when exploration is complete
rostopic echo /exploration_complete

# Visualise the ROS node graph
rqt_graph
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `Permission denied` or `cannot launch node of type` | `chmod +x ~/catkin_ws/src/ee3033_project/scripts/*.py` then `catkin_make` |
| `Package 'ee3033_project' not found` | `source ~/catkin_ws/devel/setup.bash` |
| `Map file does not exist` | Complete Stage 1 first. Check `maps/sandbox_map.yaml` exists |
| Robot doesn't move | Wait 15s for move_base to start. Check for red ERROR lines in terminal |
| YOLO not detecting | Check camera: `rostopic hz /usb_cam/image_raw`. Ensure good lighting |
| Robot not localising | In RViz, use "2D Pose Estimate" tool to manually set starting position |
| `Connection refused` to robot | Check `ROS_MASTER_URI` and `ROS_IP` on both PC and robot |

---

## Full File Tree

```
ee3033_project/
├── CMakeLists.txt
├── package.xml
├── README.md
├── launch/
│   ├── mapping.launch          # Stage 1: SLAM map building
│   ├── navigation.launch       # Loads map + AMCL + move_base
│   └── project_main.launch     # Stage 2: Full autonomous demo
├── maps/                       # Created by you in Stage 1
│   ├── sandbox_map.yaml
│   └── sandbox_map.pgm
├── param/
│   ├── costmap_common_params.yaml
│   ├── global_costmap_params.yaml
│   ├── local_costmap_params.yaml
│   └── base_local_planner_params.yaml
├── rviz/
│   └── ee3033_project.rviz
└── scripts/
    ├── exploration.py           # Autonomous frontier exploration
    └── main_controller.py       # State machine controller
```
